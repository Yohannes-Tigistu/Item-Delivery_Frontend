import { MainCard } from "../components/cards/MainCard";

export const Right = () => {
  return (
    <div className="flex flex-wrap gap-12">
      <MainCard />
      <MainCard />
      <MainCard />
      <MainCard />
      <MainCard />
      <MainCard />
    </div>
  );
};

import React from 'react'

export const Signup = () => {
  return (
    <div>Signup</div>
  )
}

